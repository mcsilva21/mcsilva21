package July0714;

public interface A {
	
	void methodA();

}
