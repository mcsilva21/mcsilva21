import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class HashMap {
	
	public static void main(String[] args) {
		
		java.util.HashMap<String, String> dic = new java.util.HashMap<String, String>();
		
		dic.put("한원선","99");
		dic.put("한홍진","97");
		dic.put("황기태","34");
		dic.put("이영희","98");
		dic.put("정원석","70");
		
		Set<String> keys = dic.keySet();
		Iterator<String> it = keys.iterator();
		System.out.println("요소의 갯수:"+dic.size());
		
		while(it.hasNext()) {
			String key = it.next();
			String value = dic.get(key);
			System.out.println(key+":"+value);
		}
			
		}
		
	}


