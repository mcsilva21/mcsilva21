
public class Ex19 {

	public static void main(String[] args) {
	 System.out.printf("100+100");
	 System.out.printf("\n");
	 System.out.printf("%d",100 + 100);
	 System.out.printf("\n");

	 System.out.printf("%d %d", 100,200);
	 System.out.printf("\n");
	 System.out.printf("%d",100);
	 System.out.printf("\n");	 
	 
	 System.out.printf("%d/%d = %.2f\n",100,200,100/200.0);
	 System.out.printf("%d/%d = %d\n",100,200,100/200);
	 
	 System.out.printf("%s\t%s","Hello","Jave");

	}

}
