package Ex02;

public class ConstrunctorEx3 {

	public static void main(String[] args) {
		B b;
		b = new B(5);
	

	}

}
