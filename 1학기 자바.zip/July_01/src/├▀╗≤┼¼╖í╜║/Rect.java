package 추상클래스;

public class Rect extends Dobject {

	@Override
	public void draw() {
		System.out.println("rect");
		
	}

}
