
public class Ex01 {

	public static void main(String[] args) {
		
		
		int x = 10;
		int y = 20;
		int z = (++x);
		int t = (y--);
		int s = (++x) + (y--);
		System.out.println(z);
		System.out.println(y);
		System.out.println(s);

	}

}
