package Ex02;

class A {
	public A() {
		System.out.println("생성자A");
	}
public A(int x) {
	System.out.println("매개변수생성자A"+x);
}
}
