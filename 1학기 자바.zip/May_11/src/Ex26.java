
public class Ex26 {

	public static void main(String[] args) {
		
		char ch = 'a';
		
		System.out.printf("%c\n",ch+1);
		System.out.printf("%c\n",ch+2);
		System.out.printf("%c\n",ch+3);
;
			
		
	}

}
