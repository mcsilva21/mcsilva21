package Upcasting;

public class UpcastingEx {

	public static void main(String[] args) {
		Person p = new Student("이재문");	
		System.out.println(p.name); // 업캐스팅 발생
							
		Student s1 = (Student) p;
		s1.grade = "A";
		s1.department  = "Com";
				
		System.out.println(s1.grade+","+s1.department);
	}

}
