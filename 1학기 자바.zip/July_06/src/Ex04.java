public class Ex04 {

	public static void main(String[] args) {
		String str = "Java를 공부하는 중, Java는 재미있어요.^^";		//0부터.스페이스도 문자열.
		
		System.out.println("문자열 ==>" + str);
		
		System.out.print("제일 처음 나오는 Java 위치 ==>");
		System.out.println(str.indexOf("Java"));		//Java 글자가 처음 나오는 위치를 출력한다.
		System.out.print("제일 마지막에 나오는 Java 위치 ==>");
		System.out.println(str.lastIndexOf("Java"));	//Java 글자가 마지막 나오는 위치를 출력한다.
		
				//탐색은 오른쪽부터 왼쪽으로. 출력은 왼쪽에서 오른쪽으로 한다.
	}

}
