package 미션;

public class PointEx {

	public static void main(String[] args) {
		

	}

}
