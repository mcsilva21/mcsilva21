package shape;

public class Shape {
	public void draw() {
		System.out.println("Shape");
	}

	public void test() {
		System.out.println("test");
	}
}

class Line extends Shape{
	@Override
	public void draw() {
		System.out.println("line");
	}
	
	

}

class Rectangle extends Shape{
	@Override
	public void draw() {
		System.out.println("rectangle");
	}
	

}
class Circle extends Shape{
	
@Override
public void draw() {
	System.out.println("circle");
}
}




