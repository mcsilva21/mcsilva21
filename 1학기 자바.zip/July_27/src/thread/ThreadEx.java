package thread;

public class ThreadEx {
	
	public static void main(String[] args) {
		
		Mythread th = new Mythread();
		th.start();
		
		
		for (int i = 0; i <500; i++) {
			System.out.println("A");
			
		}
		
		
	}

}
