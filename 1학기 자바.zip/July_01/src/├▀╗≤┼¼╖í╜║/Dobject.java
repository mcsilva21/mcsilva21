package 추상클래스;

 abstract class Dobject { //추상 클래스 선언
	public Dobject next;
	public Dobject() { next=null;}
	abstract public void draw(); //추상 메소드 선언

}
