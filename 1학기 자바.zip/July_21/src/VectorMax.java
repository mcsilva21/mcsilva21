import java.util.Scanner;
import java.util.Vector;

public class VectorMax {

	public static void main(String[] args) {
	Vector<Integer>v = new Vector<Integer>();
		Scanner scanner = new Scanner(System.in);			
		System.out.println("정수 출력될때 까지 >>>");		
		while (true) {
			int n = scanner.nextInt();
			if(n==-1)
				break;
			v.add(n);		
		}
		if(v.size()==0) {
			return;
		}
		
		int max =0;		
		for (int i = 1; i < v.size(); i++) {
			if(v.get(i)>max)
				max=v.get(i);
	}
	System.out.println("가장큰 수:"+max);
	
	}

}

