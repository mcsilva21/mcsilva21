import java.util.ArrayList;
import java.util.Scanner;

public class Score {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		Scanner scanner = new Scanner(System.in);		
		System.out.println("점수를 입력 하세요");
		for (int i = 0; i <6; i++) {
			String s = scanner.next();
			list.add(s);			
		}
		
		int sum = 0;
		for (int i = 0; i < list.size(); i++) {			
			String s = list.get(i);
			switch (s) {
			case "A":
				sum+=4;
				break;
			case "B":
				sum+=3;
				break;
			case "C":
				sum+=2;
				break;
			case "D":
				sum+=1;
				break;

			case "F":
				sum+=0;
				break;
			}
	}
		double result = (double)sum/list.size();
		System.out.println(result);

}
}
