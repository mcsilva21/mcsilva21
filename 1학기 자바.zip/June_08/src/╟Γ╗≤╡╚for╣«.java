
public class 향상된for문 {

	public static void main(String[] args) {
		int[] arr = {10,20,30,40,50};
		int sum =0;
		
		for(int n: arr)
			sum +=n;
		
		System.out.println(sum); //향상된 for문
		
		}

	}


