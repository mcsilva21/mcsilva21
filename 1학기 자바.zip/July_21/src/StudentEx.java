import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class StudentEx{			
	public static void main(String[] args) {
	
		HashMap<String,String> stu = new HashMap<String,String>();		
		
		stu.put("한원선","010-222-2222");
		stu.put("황기태","010-111-1111");
		stu.put("이영희","010-333-3333");
		
		System.out.println("HashMap의 요소 개수:" + stu.size());
		
		Set<String> keys = stu.keySet();		
		Iterator<String> it = keys.iterator();
		
		while(it.hasNext()) {
			String key = it.next();
			String value = stu.get(key);
			
				System.out.println(key+":"+value);
			}
		
	}

}
