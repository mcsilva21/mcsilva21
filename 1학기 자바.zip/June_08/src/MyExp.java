import java.io.ObjectInputStream.GetField;
import java.util.Scanner;

public class MyExp {

	int base; //필드
	int exp;

	public MyExp(int x, int y) {//생성자
		base =x;
		exp=y;
	}
	public int getValue() {
		int f= 1;
		for (int i = 1; i <= exp; i++) {	
			f*=base;
	}		
		return f;			
	}
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("밑의 값은?  ");
		int a =s.nextInt();
		
		System.out.println("지수의 값은?  ");
		int b =s.nextInt();
		
		MyExp ok = new MyExp(a,b);
		
		System.out.printf("%d의 %d승은 %d입니다.\n",a,b,ok.getValue());
						
	}
	

}
