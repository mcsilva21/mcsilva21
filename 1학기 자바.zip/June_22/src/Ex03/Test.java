package Ex03;

class User {
	String name;
	String type;

	public User(String name, String type) {
		this.name = name;
		this.type = type;
	}
}

class Student extends User {
	public Student(String name, String type) {
		super(name, type);
	}
}

class Staff extends User {
	public Staff(String name, String type) {
		super(name, type);
	}
}

class Citizen extends User {
	public Citizen(String name, String type) {
		super(name, type);
	}
}

public class Test {

//	public void useLibrary(Student student) {		
//		System.out.println(student.type+" "+student.name + "이 도서관을 이용합니다.");
//	}
//	public void useLibrary(Staff staff) {
//		System.out.println(staff.type+" "+staff.name + "이 도서관을 이용합니다.");
//	}
//	public void useLibrary(Citizen citizen) {
//		System.out.println(citizen.type+" "+citizen.name + "이 도서관을 이용합니다.");
//	}

	public void useLibrary(User user) {
		System.out.println(user.type + " " + user.name + "이 도서관을 이용합니다.");
	}

	public static void main(String[] args) {
		
		Test tt = new Test();

//		Student stu01 = new Student("홍길동","학생");
		User user = new Student("홍길동", "학생");
//		tt.useLibrary(stu01);
		tt.useLibrary(user);

//		Staff staff01 = new Staff("임꺽정","교직원");
		User user1 = new Staff("임꺽정", "교직원");
//		tt.useLibrary(staff01);
		tt.useLibrary(user1);

//		Citizen citizen01 = new Citizen("공가영","시민");	
		User user2 = new Citizen("공가영", "시민");
//		tt.useLibrary(citizen01);
		tt.useLibrary(user2);
		
		Citizen city01;
		if(user instanceof Citizen) {
			city01 = (Citizen) user;
			System.out.println("OK~");
		}
		else 
			System.out.println("Not ok~");
	}

	}
	

