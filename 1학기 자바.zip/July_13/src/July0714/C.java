package July0714;

public interface C extends A,B{
	
	void methodC();

}
