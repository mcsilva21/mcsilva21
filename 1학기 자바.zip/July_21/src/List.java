import java.util.ArrayList;
import java.util.Scanner;

public class List {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();

		Scanner sc = new Scanner(System.in);

		for (int i = 0; i <4; i++) {
			System.out.println("이름을 입력하세요>>");
			String s = sc.next();
			list.add(s);

		}
		
		for (int i = 0; i < list.size(); i++) {
			String name = list.get(i);
			System.out.println(name + "");
		}
		
		int max=0;//인덱스에서 가장 큰 수 
		
		//인덱스 비교값 for문
		for (int j = 1; j < list.size(); j++) {				
			if(list.get(j).length()>list.get(max).length())
				max=j;							
		}
		System.out.println("가장큰 글자는:"+list.get(max));					

		
	}
}



