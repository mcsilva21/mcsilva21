
public enum Week {

	MONDAY,
	TUESDAY,
	WEDNESAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
	
}
