package Ex01;

class SuperObject {
	protected String name;
	public void paint() {
		draw();
	}
	public void draw() {
		System.out.println("나는조상이다");
		System.out.println(name);
	}
}
