package July0713;

public interface RemoteControl {

	int MAX_VOLUME = 100;
	int MIN_VOLUME = 100;

	void turnOn();

	void turnOff();

	static void changeBattery() {
		System.out.println("건전지를 교환합니다.");
	}

	default void setMute(boolean mute) {
		if (mute) {
			System.out.println("무음처리 합니다.");
		} else
			System.out.println("무음 해체 합니다.");
	}

}
