
public class Ex06 {

	public static void main(String[] args) {
		int var1 = 10;
		int var2 = 012;
		int var3 = 0xA;
		                
		System.out.printf("10����:%d\n",var1);
		System.out.printf("8����:%o\n",var2);
		System.out.printf("16����:%x\n",var3);
		System.out.printf("16����:%#x",var3);
                        
	}

}
