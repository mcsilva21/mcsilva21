package 예제;

import java.util.Scanner;

public class Student extends Person {

	void set() {
		Scanner sc = new Scanner(System.in);
				
		System.out.println("나이를 입력하세요");
		age = sc.nextInt();

		System.out.println("이름를 입력하세요");
		name = sc.next();

		System.out.println("키를 입력하세요");
		height = sc.nextInt();

		System.out.println("몸무게를 입력하세요");
		setWeight(sc.nextInt());

	}

	public static void main(String[] args) {
	
		Student s = new Student();
		s.set();
//		System.out.println("저는" + s.age + "살" + s.name + "입니다." + "키는:" + s.height + "몸무게는" + s.getWeight() + "입니다.");

		
		System.out.println("저는" + s.age + "살" + s.name + "입니다." + "키는" + s.height + "몸무게는" + s.getWeight()+ "입니다.");

	}

}
