
public class Ex04 {

	public static void main(String[] args) {
		int value = 356;
		System.out.println(value-56);

	}

}
