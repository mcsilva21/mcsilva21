
public class Ex17 {

	public static void main(String[] args) {
		int a,b;
		int result;
		
		a=100;
		b=50;
		
		result = a+b;
		System.out.println(a+"+"+b+"="+result);
		
		result = a-b;
		System.out.println(a+"-"+b+"="+result);
		
		result = a*b;
		System.out.println(a+"*"+b+"="+result);
		
		result = a/b;
		System.out.println(a+"/"+b+"="+result);

	}

}
