package Ex02;

public class ConstrunctorEx {

	public static void main(String[] args) {
		C c;
		c = new C();
		
		System.out.println();

	}

}
