package Ex02;

class C  extends B{
	public C() {
		System.out.println("생성자C");
	}

}
