package July0714;

public class MultiC implements C{

	@Override
	public void methodA() {
		System.out.println("A~");
		
	}

	@Override
	public void methodB() {
		System.out.println("B~");
		
	}

	@Override
	public void methodC() {
		System.out.println("C~");
		
	}

}
