import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
	
	System.out.printf("%15s,%15s,%15s\n","Int","Square","Cube");
	
	int x = 1;
	
	System.out.printf("%15s,%15s,%15s\n",x, x*x,x*x*x );
	x++;
	System.out.printf("%15s,%15s,%15s\n",x, x*x,x*x*x );
	x++;
	System.out.printf("%15s,%15s,%15s\n",x, x*x,x*x*x );
	x++;
	System.out.printf("%15s,%15s,%15s\n",x, x*x,x*x*x );
	x++;
	System.out.printf("%15s,%15s,%15s\n",x, x*x,x*x*x );
	x++;
			
	
	}

}
