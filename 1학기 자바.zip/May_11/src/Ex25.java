
public class Ex25 {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		boolean result = a>b;
		
		System.out.printf("%s\n",result);
		
		
		
		
		
		
	}

}
