
public class Ex06_별차례로구하기 {

	public static void main(String[] args) {
		
		// 바깥 는 행을 제어
		//바깥 열을 제어		
		
		for(int j=1; j<=5; j++) {   
			for(int i=1; i<=j; i++)
				System.out.print("*");			
				System.out.println();
		}
	
	

	}

	}

