package July0713;

public interface ReT {

	int MAX_VOLUME = 100;
	int MIN_VOLUME = 100;

	void turnOn();

	void turnOff();
	
	default void testJJ() {};

	default void setMute(boolean mute) {
		System.out.println("무음처리");
	}

	static void setValue() {

	}

}
