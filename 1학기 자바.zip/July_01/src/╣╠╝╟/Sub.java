package 미션;

class Sub extends Calc {

	@Override
	int calculate() {
		
		return a-b;
	}
	
	
}
