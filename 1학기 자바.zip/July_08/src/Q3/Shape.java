package Q3;

abstract public class Shape {
	
	static double area;
	static String color;
	static String type;
	
	static final String TYPE1 = "CIRCLE";
	static final String TYPE2 = "TRIANGLE";
	static final String TYPE3 = "RECTANGLE";
	
	public Shape(double area, String color, String type) {
		
	}
	public void draw(String color,String type) {
		System.out.println(color+"로"+type+"을 그립니다." );
	}
	public void setDate() {}
	
	public void getArea(int a) {
		System.out.println("도형 " +TYPE1 +" 의 면적 :"+ + a*a*3.14);
	}
	public void getArea2(int h, int h2) {
		System.out.println("도형 " +TYPE2 +" 의 면적 :"+ + h/2*h2);
	}
	public void getArea3(int h3, int h4) {
		System.out.println("도형 " +TYPE3 +" 의 면적 :"+ + h3*h4);
	}
	
}
