package 미션;

public class PointException extends Exception{

		public PointException() {}
		public PointException(String message) {
			super(message);
		}			
		}
	
	

