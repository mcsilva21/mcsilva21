import java.util.Scanner;

public class Ex08 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in); 	
		String str;
		
		System.out.println("���ڸ� �Է��ϼ���");
		int x = scan.nextInt();
		
		if(x % 2 == 0) {
			System.out.println("¦��");	
			
	   } else {
		   System.out.println("Ȧ��");	
	   }
		
		
	
}
}