package Q3;

import java.util.Scanner;

public class ShapeEx extends Shape{

	public ShapeEx() {
		super(area, color, type);		
	}
	
	public static void menu() {
	      System.out.println("[[도형선텍]]");
	      System.out.println("1.CIRCLE"+"2.TRIANGLE"+"3.RECTANGLE"+"4.EXIT");
	      System.out.println("메뉴 선택:");
	   }
	
	public static void main(String[] args) {
		Shape x = new ShapeEx();		
		Scanner s = new Scanner(System.in);
		
		while (true) {
			menu();
			int n = s.nextInt();
			if (n == 4) {
				System.out.println("프로그램종료합니다.");
				return;
			}		
			if (n < 1 || n > 4) {
				System.out.println("존재 하지 않습니다. 숫자를 다시 입력해 주세요");
				continue;
			}
			
			 switch(n) {
	         case 1: 	System.out.println("[선택한 도형 "+TYPE1+"의  면적]");
	         			System.out.println("원의 반지름:");
	         			int a = s.nextInt();
	         			x.getArea(a);
	         			System.out.println("["+TYPE1+"의 드로잉]");
	         			System.out.println("색상선택 >> (1)Red (2)Green (3)Blue");
	         			String str = s.next();
	         			x.draw(str,TYPE1);	
	         			break;
	         case 2:
				        System.out.println("[선택한 도형 "+TYPE2+"의  면적]");
			  			System.out.println("너비:");
			  			int h = s.nextInt();
			  			System.out.println("높이:");
			  			int h2 = s.nextInt();
			  			x.getArea2(h, h2);
			  			System.out.println("["+TYPE2+"의 드로잉]");
			  			System.out.println("색상선택 >> (1)Red (2)Green (3)Blue");
			  			String str2 = s.next();
	         			x.draw(str2,TYPE2);
			  			break;
		  			
	         case 3:
				        System.out.println("[선택한 도형 "+TYPE3+"의  면적]");
				        System.out.println("너비:");
			  			int h3 = s.nextInt();
			  			System.out.println("높이:");
			  			int h4 = s.nextInt();
			  			x.getArea3(h3, h4);
			  			System.out.println("["+TYPE3+"의 드로잉]");
			  			System.out.println("색상선택 >> (1)Red (2)Green (3)Blue");
			  			String str3 = s.next();
	         			x.draw(str3,TYPE3);
			  			break; 
	}
}

}
}