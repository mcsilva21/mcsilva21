import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class HashMapEx {
	
	public static void main(String[] args) {
		
		java.util.HashMap<String, String> dic = new java.util.HashMap<String, String>();
		
		dic.put("love","사랑");
		dic.put("apple","사과");
		dic.put("baby","아기");
		
		Set<String> keys = dic.keySet();
		Iterator<String> it = keys.iterator();
		while(it.hasNext()) {
			String key = it.next();
			String value = dic.get(key)
;
				System.out.println(key+value);
			}
		
		Scanner scanner = new			
				Scanner(System.in);
		for (int i = 0; i <3; i++) {
			System.out.println("찾고싶은 단어는?");
			String eng = scanner.next();
			System.out.println(dic.get(eng));
		}
		
	}

}
