
public class Ex16 {

	public static void main(String[] args) {
		int Value = 50;
		int result = Value + 50;
		System.out.println("result:"+ result);
		
		

	}

}
