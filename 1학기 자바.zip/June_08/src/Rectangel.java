import java.util.Scanner;

public class Rectangel {
	
	int width;
	int height;

	public Rectangel(int a, int b) { //생성자
		width =a;
		height=b;
	}
	public int getArea() {		
		return width*height;			
	}
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("너비?");
		int x =s.nextInt();
		
		System.out.println("높이?");
		int y =s.nextInt();
		
		Rectangel ok = new Rectangel(x,y);
		
		System.out.printf("사각형의 면적은%d입니다.",ok.getArea());
						
	}

}
