package July0714;

public interface B {
	void methodB();
}
