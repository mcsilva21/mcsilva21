package 추상클래스;

public class Line extends Dobject {

	@Override
	public void draw() { //실행부를 구현해야함.
		System.out.println("Line");
		
	}

}
