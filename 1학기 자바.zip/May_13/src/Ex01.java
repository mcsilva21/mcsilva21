
public class Ex01 {

	public static void main(String[] args) {
		int x = 10;
		int y = 20;
		boolean boo1;
		
		boo1 = x > y;
		System.out.println("���:" +boo1);
		
		boo1 = x >= y;
		System.out.println("���:" +boo1);
		
		boo1 = x <= y;
		System.out.println("���:" +boo1);
				
		boo1 = x == y;
		System.out.println("���:" +boo1);
	
		boo1 = x != y;
		System.out.println("���:" +boo1);
		
		System.out.println("���:" +!boo1);
		

	}

}
