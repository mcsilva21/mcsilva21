package Ex01;

public class UsingOverride {
	private void mian() {
		DObject start,last,obj;
		
		start = new Line(); // Line 객체 연결
		last = start;
		obj = new Rect(); //Rect 객체 연결
		last.next = obj;
		last = obj;
		obj = new Line(); // Line 객체 연결
		last.next = obj;
		last = obj;
		obj = new Circle(); // Circle 객체 연결
		last.next = obj;
		//모든 도형 출력
		DObject p = start;
		while(p!=null) {
			p.draw();
			p=p.next;
		}
	}

}
