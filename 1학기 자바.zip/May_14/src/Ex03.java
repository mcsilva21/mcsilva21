
public class Ex03 {

	public static void main(String[] args) {
		int pencils = 534;
		int student =30;
		
		int pencilsPerStudent = pencils/student;
		System.out.println(pencilsPerStudent);
		
		int pencilsPerStudent1 = pencils%student;
		System.out.println(pencilsPerStudent1);
	}

}
