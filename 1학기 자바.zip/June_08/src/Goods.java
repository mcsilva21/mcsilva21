
public class Goods {

		public String name;
		public int price;
		public int numberOfStock;
		public int sold;


	public Goods(String name2, int price2, int n, int sold2) {
			name = name2;
			price = price2;
			numberOfStock =n;
			sold = sold2;
		}

	public Goods() {		
	}
	public String getName() {
		return name;
	}

	public int getPrice() {
		return price;
	}
	public int getNumberOfStock() {
		return numberOfStock;
	}
	public int getSold() {
		return sold;
	}

}
