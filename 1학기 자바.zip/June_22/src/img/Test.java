package img;

import monday.Goods;

public class Test {
	
	public static void main(String[] args) {
		Goods ok = new Goods();
		ok.name = "TV";
		System.out.println(ok);
	}
}
