import java.util.Scanner;

public class 대소문자변환 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("문자열 입력 :");
        String input=sc.nextLine();
        
        char[] arr;
        arr= input.toCharArray();
        
        for(int i=0; i<arr.length; ++i){
            if(65<=arr[i] && arr[i]<=90){
                arr[i]=(char)(arr[i]+32); //대문자면 32를 더하고
                continue;
                }
            if (97<=arr[i] && arr[i]<=122){
                arr[i]=(char)(arr[i]-32); //소문자면 32를 빼
                continue;
            }
            }      
            System.out.print(arr);
        }
    }