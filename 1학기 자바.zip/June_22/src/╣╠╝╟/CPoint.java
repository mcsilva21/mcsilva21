package 미션;

class CPoint {
	int a;
	int b;
	
	public CPoint(int a,int b) {
		this.a=a;
		this.b=b;			
	}
	
	public void show() {
	 System.out.println("("+a+","+b+")");
}

	public void show2(String color) {
		 System.out.println("("+a+","+b+","+color+")");
	}
	
}
