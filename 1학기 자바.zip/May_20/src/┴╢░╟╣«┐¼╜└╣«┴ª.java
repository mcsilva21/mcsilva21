
public class 조건문연습문제 {

	public static void main(String[] args) {
	
		
		//연습문제 1
		int sum=0;
		
		for(int i=3; i<=100; i++) 
			if( i%3 == 0){
			sum += i++;
			
		}
		System.out.println("3의 배수의 합은:"+sum);
		
		System.out.println();
		
		//연습문제 2
	
		int x;
		int y;
		
		while(true){
			x = (int)(Math.random()*6)+1;
			y = (int)(Math.random()*6)+1;
			
			System.out.println(x + "," + y);
					
		 if (x+y ==5)
			break;
			
		
		}
		System.out.println("종료합니다.");
		System.out.println();
		//연습문제 3
		
		int X;
		int Y;
		
		for(X=1; X<=10; X++);
		for(Y=1; Y<=10; Y++)
		
		if(4*X+5*Y==60)
			System.out.println(X+","+Y);
		else break;
		
			 
		 }
	}




