package 미션;

class Div extends Calc {

	@Override
	int calculate() {
	
		return a/b;
	}
	
	}
	


