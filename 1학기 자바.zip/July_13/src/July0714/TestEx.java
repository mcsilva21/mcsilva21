package July0714;

public class TestEx {
	
	public int Tues() {		

//인스턴스 멤버는 객체를 생성해야  heap영역이 만들어짐
//->static은 heap이 만들어 지지 않고 메소드 영역에서 생성이 됨 
		
		Test t = new Test();		
		int ok;
		ok = Test.x + t.y;
		return ok;
	}
			
	public static void main(String[] args) {
		//Tues는 TestEx안에 생성된 객체이므로, TestEx 기반의 객체를 생성하고 호출 해야함.
		
			TestEx Tues = new TestEx();
			System.out.println(Tues.Tues());
		
	}

	}


