package Ex01;

public class SubObject extends SuperObject {
	protected String name;
	
	public void test() {
		System.out.println("테스트임");
	}

	public void draw() {
		System.out.println("나는 자식이다");
		name = "Sub";
		super.name = "Super";
		super.draw();
		System.out.println(name);
	}

	public static void main(String[] args) {
		SuperObject a = new SuperObject();
		a.draw();
		
//		SubObject b = new SubObject();
//		b.draw();
//		System.out.println("***");
//		b.paint();
	}
}