public class Ex08 {

	public static void main(String[] args) {
		String str1 = "Java Programming";		//문자열 변수 2개를 초기
		String str2 = "Java IT CookBook";

		System.out.println("원 문자열1 ==> [" + str1 + "]");
		System.out.println("원 문자열2 ==> [" + str2 + "]");
		
		System.out.println(str1.compareTo(str2));		//두 문자열을 비교한다. 7 (다르면 더 비교할 필요가 없다. P-I)
		System.out.println(str1.contains("Java"));		//"Java"글자가 포함되었는지 확인한다. true
		
	}

}
