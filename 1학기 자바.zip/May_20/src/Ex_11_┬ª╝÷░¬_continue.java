import java.util.Scanner;

public class Ex_11_짝수값_continue {

	public static void main(String[] args) {

		int cnt = 0;
		
		go:
		
		for(int i=1; i<=3; i++) {
			cnt++;
			System.out.printf("\n[%d행]\n",i);
			
			for(int j=1; j<=3; j++) {
				System.out.println("Inner for loop~");
				
				if(cnt ==2)
					break go;
			}
			System.out.println("\nOuter for loop");
		}
		
		System.out.println("찾았다");
		
		
		
		
		
		
	}

}
