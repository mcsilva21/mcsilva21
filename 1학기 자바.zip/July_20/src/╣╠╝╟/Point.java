package 미션;

import java.util.Scanner;

public class Point {
	

		   int x;
		   int y;

		   Point(int x, int y){
		      this.x = x;
		      this.y = y;
		   }


		   static double distance(Point p1, Point p2){
		      double distance = Math.sqrt(Math.pow(p1.x-p2.x,2) + Math.pow(p1.y-p2.y,2));
		      return distance;
		   }
		   public void withdraw(double distance) throws PointException{
		      if(distance == 0) {
		         System.out.println("두 점 사이의 거리를 구할 수 없습니다.");
		      }
		   }

}
	

