package monday;

public class Point {
	protected int x,y;
	
	protected void set(int x,int y) {
		this.x =x;
		this.y = y;
	}

	protected void showPoint(){
		System.out.println("("+x+","+y+")");
	}
}
