package Q2;
public class User {

	String name;
	String type;

	public User(String name, String type) {
		this.name = name;
		this.type = type;
	}

}

class Student extends User {

	public Student(String name, String type) {
		super(name, type);
	}
}

class Staff extends User {

	public Staff(String name, String type) {
		super(name, type);
	}
}

class Citizen extends User {

	public Citizen(String name, String type) {
		super(name, type);
	}
}
