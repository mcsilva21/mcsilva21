import java.util.Scanner;

public class Ex10 {


	public static void main(String[] args) {
		//입력된 문자열을 거꾸로 출력
		Scanner s = new Scanner(System.in);
		String str;
		
		System.out.print("문자열 입력 ==>");
		str = s.nextLine();

		System.out.print("문자열 출력 ==>");
		
		for(int i=str.length()-1; i>=0; i--)		//문자열을 거꾸로 해야하니 숫자가 거꾸로 간다. 
			System.out.printf("%c",str.charAt(i));
	}

}