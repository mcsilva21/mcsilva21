package July0714;

public class Test {
	static int x = 10;
	int y = 100;

}
