package Ex02;

public class ConstrunctorEx2 {

	public static void main(String[] args) {
		B B;
		B = new B();
		
		System.out.println();

	}

}
