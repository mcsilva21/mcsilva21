
public class Ex03 {
	
	public static void main(String[] args) {
		
		try {
			method2();
		} catch (ClassNotFoundException e) {
			
			System.out.println("클래스가 존재 하지 않습니다.");
		}			
	}
	
	public static void method2() throws ClassNotFoundException{
		Class clazz = Class.forName("java.lang.String2");
		
	}
	
	
}